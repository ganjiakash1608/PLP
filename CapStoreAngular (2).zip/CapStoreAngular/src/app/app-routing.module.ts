import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MerchantInventoryComponent } from './merchant-inventory/merchant-inventory.component';
import { AddNewProductComponent } from './add-new-product/add-new-product.component';

const routes: Routes = [


  { path:'', redirectTo:'', pathMatch:'full' },
  { path:'inventory', component:MerchantInventoryComponent, pathMatch:'full'},
  { path:'addnewproduct', component:AddNewProductComponent, pathMatch:'full'},
  { path:'**', redirectTo:'/merchant-inventory', pathMatch:'full' }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
