import { NgModule } from '@angular/core';
import {  MatButtonModule, MatMenuModule } from '@angular/material';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  imports: [
    MatButtonModule,
    MatSidenavModule,MatMenuModule,
    MatInputModule,
    MatSelectModule
  ],
  exports: [
    MatButtonModule,
    MatSidenavModule,MatMenuModule,
    MatInputModule,
    MatSelectModule
  ]
})
export class MaterialModule { }
