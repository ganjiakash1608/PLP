export class MerchantInventoryModel {
    productId: number;
    productCategory: String;
    productName: String;
    productDesc: String;
    productQuantity: number;
    productprice: number;
    
}
