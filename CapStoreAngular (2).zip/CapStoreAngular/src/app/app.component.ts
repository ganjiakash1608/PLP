import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private routes: Router){}

  title = 'CapStore';
  showFiller = false;

  routeToA() {
    // navigate to home page on click of Go to Home button
    this.routes.navigate(['/inventory']);
  }
}
