import { Injectable } from '@angular/core';
import { MerchantInventoryModel } from '../model/merchantInventory';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class MerchantDisplayService {
  merchantInventoryArr : MerchantInventoryModel[];
  static counter:number=1001;

  constructor(private routes: Router) {
    this.merchantInventoryArr=[]
   }

   add(inventory:MerchantInventoryModel){
    inventory.productId=MerchantDisplayService.counter++;
    this.merchantInventoryArr.push(inventory);
    this.routes.navigate(['/inventory']);
  }
  display() {
    return this.merchantInventoryArr;
  }
  
  remove(index: number) {
    this.merchantInventoryArr.splice(index, 1);
  }
  getDetailsOf(index) {
    return this.merchantInventoryArr[index];
  }
}
