import { TestBed } from '@angular/core/testing';

import { MerchantDisplayService } from './merchant-display.service';

describe('MerchantDisplayService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MerchantDisplayService = TestBed.get(MerchantDisplayService);
    expect(service).toBeTruthy();
  });
});
