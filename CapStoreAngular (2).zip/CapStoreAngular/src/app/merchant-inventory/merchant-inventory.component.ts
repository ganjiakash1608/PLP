import { Component, OnInit } from '@angular/core';
import { MerchantInventoryModel } from '../model/merchantInventory';
import { MerchantDisplayService } from '../services/merchant-display.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-merchant-inventory',
  templateUrl: './merchant-inventory.component.html',
  styleUrls: ['./merchant-inventory.component.css']
})
export class MerchantInventoryComponent implements OnInit {
  merchantInventory: MerchantInventoryModel[];
  confirmationStatus: boolean;
  receivedMerchantInventory: MerchantInventoryModel;
  constructor(private router: Router, private merchantService: MerchantDisplayService) {
    // this.merchantInventory = new MerchantInventoryModel();
    this.merchantInventory = [];
    this.merchantInventory = this.merchantService.display();
  }

  ngOnInit() {
  }
  addQuantity(index) {
    this.receivedMerchantInventory = this.merchantService.getDetailsOf(index);
    this.receivedMerchantInventory.productQuantity++;
  }
  deleteInventory(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the product?');
    if (this.confirmationStatus) {
      //this.merchantService.remove(index);
      this.receivedMerchantInventory = this.merchantService.getDetailsOf(index);
      this.receivedMerchantInventory.productQuantity--;
    }
  }
  deleteProduct(index: number){
    this.confirmationStatus = confirm('Do you want to delete the product?');
    if (this.confirmationStatus) {
      this.merchantService.remove(index);
  }
}
  addNewProduct() {
    this.router.navigate(['/addnewproduct']);
  }
}
