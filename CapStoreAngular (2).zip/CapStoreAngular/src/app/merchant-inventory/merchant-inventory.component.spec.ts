import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantInventoryComponent } from './merchant-inventory.component';

describe('MerchantInventoryComponent', () => {
  let component: MerchantInventoryComponent;
  let fixture: ComponentFixture<MerchantInventoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantInventoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantInventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
