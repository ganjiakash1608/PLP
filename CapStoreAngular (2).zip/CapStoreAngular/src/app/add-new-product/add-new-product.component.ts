import { Component, OnInit } from '@angular/core';
import { MerchantInventoryModel } from '../model/merchantInventory';
import { MerchantDisplayService } from '../services/merchant-display.service';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-add-new-product',
  templateUrl: './add-new-product.component.html',
  styleUrls: ['./add-new-product.component.css']
})
export class AddNewProductComponent implements OnInit {
  merchantInventory: MerchantInventoryModel;
  confirmationStatus: boolean;
  // form controls
  productNameControl = new FormControl('', [
    Validators.required,
  ]);

  productCategoryControl = new FormControl('', [
    Validators.required,
  ]);

  productDetailsControl = new FormControl('', [
    Validators.required,
  ]);

  productPriceControl = new FormControl('', [
    Validators.required,
  ]);
  
  productQuantityControl = new FormControl('', [
    Validators.required,
  ]);


  constructor(private router: Router, private merchantService: MerchantDisplayService) {
    this.merchantInventory = new MerchantInventoryModel();

  }


  addInventory() {
    this.merchantService.add(this.merchantInventory);
  }
  deleteInventory(index: number) {
    // ask user confirmation on delete
    this.confirmationStatus = confirm('Do you want to delete the product?');
    if (this.confirmationStatus) {
      this.merchantService.remove(index);
    }
  }

  ngOnInit() {
  }

}
